import os

WEBHOOK= os.environ['WEBHOOK']
CHANNEL= os.environ['CHANNEL']
CUSTOM_CHANNELS={}
